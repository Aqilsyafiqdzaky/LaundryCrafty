<?php 
include "../db.php";
$result = mysqli_query($conn, "SELECT * FROM pelanggan");
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<h2>Data Pelanggan</h2>
<a href="create.php">Tambah Pelanggan</a>
<a href="../index.php">Kembali</a>

<table>
    <tr>
        <th>ID</th><th>Nama</th><th>No Telp</th><th>Aksi</th>
    </tr>
    <?php while($row = mysqli_fetch_assoc($result)): ?>
    <tr>
        <td><?= $row['id']; ?></td>
        <td><?= $row['nama']; ?></td>
        <td><?= $row['telp']; ?></td>
        <td>
            <a href="edit.php?id=<?= $row['id']; ?>">Edit</a>
            <a href="delete.php?id=<?= $row['id']; ?>">Hapus</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
</body>
</html>
