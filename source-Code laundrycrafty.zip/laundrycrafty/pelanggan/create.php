<?php include "../db.php"; ?>

<?php
if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $telp = $_POST['telp'];

    mysqli_query($conn, "INSERT INTO pelanggan VALUES(NULL, '$nama', '$telp')");
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="../style.css"></head>
<body>
<h2>Tambah Pelanggan</h2>
<form method="post">
    Nama:
    <input type="text" name="nama" required>
    No Telp:
    <input type="text" name="telp" required>
    <button type="submit" name="submit">Simpan</button>
</form>
</body>
</html>
