<?php 
include "../db.php";
$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM pelanggan WHERE id=$id"));

if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $telp = $_POST['telp'];

    mysqli_query($conn, "UPDATE pelanggan SET nama='$nama', telp='$telp' WHERE id=$id");
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="../style.css"></head>
<body>
<h2>Edit Pelanggan</h2>

<form method="post">
    Nama:
    <input type="text" name="nama" value="<?= $data['nama']; ?>" required>
    No Telp:
    <input type="text" name="telp" value="<?= $data['telp']; ?>" required>
    <button type="submit" name="submit">Update</button>
</form>
</body>
</html>
