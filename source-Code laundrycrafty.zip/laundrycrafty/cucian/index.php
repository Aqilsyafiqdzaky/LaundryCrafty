<?php 
include "../db.php";
$result = mysqli_query($conn, "SELECT * FROM cucian");
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="../style.css"></head>
<body>
<h2>Data Cucian</h2>

<a href="create.php">Tambah Cucian</a>
<a href="../index.php">Kembali</a>

<table>
<tr>
    <th>ID</th><th>Pelanggan</th><th>Berat</th><th>Total Harga</th><th>Tanggal</th><th>Aksi</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)): ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['nama_pelanggan'] ?></td>
    <td><?= $row['berat'] ?> kg</td>
    <td>Rp <?= number_format($row['total_harga']) ?></td>
    <td><?= $row['tanggal'] ?></td>
    <td>
        <a href="edit.php?id=<?= $row['id'] ?>">Edit</a>
        <a href="delete.php?id=<?= $row['id'] ?>">Hapus</a>
    </td>
</tr>
<?php endwhile; ?>
</table>
</body>
</html>
