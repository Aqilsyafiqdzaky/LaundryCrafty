<?php 
include "../db.php";

$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM cucian WHERE id=$id"));
$pelanggan = mysqli_query($conn, "SELECT * FROM pelanggan");

if (isset($_POST['submit'])) {
    $pid = $_POST['pelanggan_id'];
    $pel = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM pelanggan WHERE id=$pid"))['nama'];

    $berat = $_POST['berat'];
    $harga = $berat * 7000; // contoh perhitungan otomatis
    $tgl = $_POST['tanggal'];

    mysqli_query($conn, "UPDATE cucian SET 
        pelanggan_id='$pid',
        nama_pelanggan='$pel',
        berat='$berat',
        total_harga='$harga',
        tanggal='$tgl'
        WHERE id=$id
    ");

    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="../style.css"></head>
<body>

<h2>Edit Cucian</h2>

<form method="post">
    Pelanggan:
    <select name="pelanggan_id">
        <?php while ($p = mysqli_fetch_assoc($pelanggan)): ?>
        <option value="<?= $p['id'] ?>" 
            <?= ($p['id'] == $data['pelanggan_id']) ? 'selected' : '' ?>>
            <?= $p['nama'] ?>
        </option>
        <?php endwhile; ?>
    </select>

    Berat Cucian (kg):
    <input type="number" step="0.1" name="berat" value="<?= $data['berat'] ?>" required>

    Tanggal:
    <input type="date" name="tanggal" value="<?= $data['tanggal'] ?>" required>

    <button type="submit" name="submit">Update</button>
</form>

</body>
</html>
