<?php 
include "../db.php";
$pelanggan = mysqli_query($conn, "SELECT * FROM pelanggan");

if (isset($_POST['submit'])) {
    $pid = $_POST['pelanggan_id'];
    $pel = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama FROM pelanggan WHERE id=$pid"))['nama'];

    $berat = $_POST['berat'];
    $harga = $berat * 7000; // contoh
    $tgl = $_POST['tanggal'];

    mysqli_query($conn, "INSERT INTO cucian VALUES(NULL, '$pid', '$pel', '$berat', '$harga', '$tgl')");
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="../style.css"></head>
<body>

<h2>Tambah Cucian</h2>
<form method="post">
    Pilih Pelanggan:
    <select name="pelanggan_id">
        <?php while ($p = mysqli_fetch_assoc($pelanggan)): ?>
        <option value="<?= $p['id'] ?>"><?= $p['nama'] ?></option>
        <?php endwhile; ?>
    </select>

    Berat Cucian (kg):
    <input type="number" step="0.1" name="berat" required>

    Tanggal:
    <input type="date" name="tanggal" required>

    <button name="submit">Simpan</button>
</form>
</body>
</html>
