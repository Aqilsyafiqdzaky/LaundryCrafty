<?php 
include "../db.php";

$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM transaksi WHERE id=$id"));
$cucian = mysqli_query($conn, "SELECT * FROM cucian");

if (isset($_POST['submit'])) {
    $pid = $_POST['pelanggan_id'];
    $nama = $_POST['nama_pelanggan'];
    $tgl = $_POST['tanggal_transaksi'];

    mysqli_query($conn, "UPDATE transaksi SET 
        pelanggan_id='$pid',
        nama_pelanggan='$nama',
        tanggal_transaksi='$tgl'
        WHERE id=$id
    ");

    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="../style.css"></head>
<body>

<h2>Edit Transaksi</h2>

<form method="post">

    Pilih Data Cucian:
    <select name="pelanggan_id" onchange="updateData(this)">
        <?php while ($c = mysqli_fetch_assoc($cucian)): ?>
        <option value="<?= $c['pelanggan_id'] ?>"
                data-nama="<?= $c['nama_pelanggan'] ?>"
                data-tgl="<?= $c['tanggal'] ?>"
                <?= ($c['pelanggan_id'] == $data['pelanggan_id']) ? 'selected' : '' ?>>
            <?= $c['nama_pelanggan'] ?> - <?= $c['tanggal'] ?>
        </option>
        <?php endwhile; ?>
    </select>

    Nama Pelanggan:
    <input type="text" id="nama" name="nama_pelanggan" value="<?= $data['nama_pelanggan'] ?>" readonly>

    Tanggal Transaksi:
    <input type="date" id="tgl" name="tanggal_transaksi" value="<?= $data['tanggal_transaksi'] ?>" readonly>

    <button type="submit" name="submit">Update</button>
</form>

<script>
function updateData(sel){
    document.getElementById('nama').value = sel.options[sel.selectedIndex].dataset.nama;
    document.getElementById('tgl').value = sel.options[sel.selectedIndex].dataset.tgl;
}
</script>

</body>
</html>
