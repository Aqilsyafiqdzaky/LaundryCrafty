<?php 
include "../db.php";
$result = mysqli_query($conn, "SELECT * FROM transaksi");
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="../style.css"></head>
<body>
<h2>Data Transaksi</h2>

<a href="create.php">Tambah Transaksi</a>
<a href="../index.php">Kembali</a>

<table>
<tr>
    <th>ID</th><th>Pelanggan</th><th>Tanggal</th><th>Aksi</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)): ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['nama_pelanggan'] ?></td>
    <td><?= $row['tanggal_transaksi'] ?></td>
    <td>
        <a href="edit.php?id=<?= $row['id'] ?>">Edit</a>
        <a href="delete.php?id=<?= $row['id'] ?>">Hapus</a>
    </td>
</tr>
<?php endwhile; ?>
</table>
</body>
</html>
