<?php 
include "../db.php";
$cucian = mysqli_query($conn, "SELECT * FROM cucian");

if (isset($_POST['submit'])) {
    $pid = $_POST['pelanggan_id'];
    $nama = $_POST['nama_pelanggan'];
    $tgl = $_POST['tanggal_transaksi'];

    mysqli_query($conn, "INSERT INTO transaksi VALUES(NULL, '$pid', '$nama', '$tgl')");
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="../style.css"></head>
</head>
<body>

<h2>Tambah Transaksi</h2>

<form method="post">
    Pilih Data Cucian:
    <select name="pelanggan_id" onchange="updateData(this)">
        <?php while ($c = mysqli_fetch_assoc($cucian)): ?>
        <option value="<?= $c['pelanggan_id'] ?>" 
                data-nama="<?= $c['nama_pelanggan'] ?>" 
                data-tgl="<?= $c['tanggal'] ?>">
            <?= $c['nama_pelanggan'] ?> - <?= $c['tanggal'] ?>
        </option>
        <?php endwhile; ?>
    </select>

    Nama:
    <input type="text" id="nama" name="nama_pelanggan" readonly>

    Tanggal Transaksi:
    <input type="date" id="tgl" name="tanggal_transaksi" readonly>

    <button name="submit">Simpan</button>
</form>

<script>
function updateData(sel){
    var nama = sel.options[sel.selectedIndex].dataset.nama;
    var tgl = sel.options[sel.selectedIndex].dataset.tgl;
    document.getElementById('nama').value = nama;
    document.getElementById('tgl').value = tgl;
}
window.onload = () => updateData(document.querySelector("select"));
</script>

</body>
</html>
